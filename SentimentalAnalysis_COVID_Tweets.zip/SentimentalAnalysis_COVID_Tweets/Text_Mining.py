#------------------------ Sentimental Analysis -------------
''' Importing all the required packages '''
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from multiprocessing import Process
import time
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB

''' This function is used for calculating the raios and plotting the histogram'''
def map_plot(df_tweets_tokenized_latest):
    #Plotting the histogram for for 1.3
    # Calcaulte the ratio
    #   1. Drop the duplicate from dataframe containing the Tweet, Tocknized words and tweetcount column. This will remove the words
    #   that appear in the same tweets more than once
    #   2. Count the number of words by tweet
    #   3. Create a new column calculating the total number of tweets
    #   4. Divide columns calcaulted from step 2/ column calculated from step 3 to give the ratio
    #   5. Rese the Index of the column
    #   6. Save the plot in the 'outputs' folder
    total_tweets=max(df_tweets_tokenized_latest.index.values)
    tweets_histogram=df_tweets_tokenized_latest.drop_duplicates()
    tweets_histogram=tweets_histogram[['TokenizedWords','TweetCount']].groupby(['TokenizedWords'],as_index=False).sum()
    tweets_histogram['TotalTweets']=total_tweets
    
    tweets_histogram['Ratio']=tweets_histogram['TweetCount']/tweets_histogram['TotalTweets']
    tweets_histogram = tweets_histogram.sort_values('Ratio').reset_index()


    plt.plot(tweets_histogram.index.values, tweets_histogram['Ratio'])
    plt.xlabel('Index of the Words')
    plt.ylabel('Ratio of words/tweets')
    plt.savefig('outputs/Words_histogram.png')
    print('The Image has been saved in the outputs folder')
    
''' This function is used for producing a Multinominal Naive Bayes Classifier from 
    a count vectorised numpy array of term-document matrix '''
def binomial_nb(df_tweet):

    # Use the countvectoriser to convert the dataframe to a term document matrix
    vectorizer = CountVectorizer()
    corpus = df_tweet['ModifiedTweet'].to_numpy()
    class_sentiment=df_tweet['Sentiment'].to_numpy()
    WordMatrix = vectorizer.fit_transform(corpus)

    #Fitting the Multinominal Naive Bayes Theorem for the term document matrix
    clf = MultinomialNB()
    clf.fit(WordMatrix, np.array(class_sentiment))
    
    #Predict the values of the term document matrix
    y_predicted=clf.predict(WordMatrix)
    
    #Calculate the score
    score=clf.score(WordMatrix,np.array(class_sentiment))
    print('Score:',score)
    #Print the error rate and mis-classified rates
    print("Number of mislabeled points out of a total" ,len(df_tweet), "points :" ,(np.array(df_tweet['Sentiment']) != y_predicted).sum())
    print("Percentage Misclassified:",(np.array(df_tweet['Sentiment']) != y_predicted).sum()/ len(df_tweet)*100)


'''----------------This function is used for ------------------
                  1. Removing the characters <=2 characters
                  2. The Stop words to be removed
                  3. Call the map_plot function to plot thte histogram
'''
def Tweet_Process_2(df_tweet):

    stop_words=['your', 'what', 'very', 'hasn', 'still', 'for', 'having', 'of', 'out', 'youd', 'm', 'they', 'till', 't', 'his', 'herself', 'our', 'those', 'further', 'up', 'youre', 'there', 'can', 'dont', 'who', 'before', 'themselves', 'my', 'is', 'during', 'by', 'too', 'him', 'do', 'needn', 'under', 'himself', 's', 'y', 'which', 'shant', 'being', 'about', 'aren', 'both', 'shan', 'werent', 'an', 'so', 'again', 'were', 'down', 'yourself', 'to', 'arent', 'shouldve', 'itself', 'ur', 'more', 'mustnt', 'that', 'where', 'below', 'don', 'their', 'youve', 'we', 'through', 'them', 'yourselves', 'll', 'as', 'wasn', 'couldn', 'these', 'than', 'the', 'mightnt', 'on', 'didn', 'she', 'he', 'been', 'once', 'hers', 'youll', 'hadn', 'wasnt', 'few', 'ain', 'mustn', 'did', 'above', 'each', 'me', 'its', 'weren', 'ma', 'at', 'when', 'whom', 've', 'because', 'then', 'ive', 'shes', 'here', 'some', 'you', 're', 'theirs', 'was', 'ours', 'this', 'while', 'from', 'myself', 'are', 'own', 'o', 'most', 'into', 'mightn', 'other', 'has', 'isn', 'now', 'nor', 'doesn', 'thatll', 'with', 'haven', 'not', 'all', 'be', 'and', 'but', 'shouldn', 'a', 'yours', 'in', 'against', 'also', 'after', 'hadnt', 'her', 'how', 'won', 'urs', 'same', 'between', 'until', 'only', 'just', 'over', 'or', 'ourselves', 'doing', 'if', 'am', 'any', 'had', 'will', 'off', 'd', 'i', 'wouldn', 'such', 'it', 'why']

    df_tweets_tokenized=df_tweet.explode('TokenizedWords')

#Total number of words including repititions
    print('\n','Total number of words including repetitions')
    print(df_tweets_tokenized['TokenizedWords'].count())

#Total number of distinct words
    print('\n','Total number of distinct words')
    print(len(df_tweets_tokenized['TokenizedWords'].unique()))


#Most 10 frequent words in the corpus before removing the stop words and the 2 letter words
    print('\n','Most 10 frequent words in the corpus before removing the stop words and the 2 letter words')
    print(df_tweets_tokenized[['TokenizedWords','TweetCount']].groupby(['TokenizedWords'],as_index=False).sum().nlargest(10,'TweetCount').to_string(index=False))


    df_tweets_tokenized['TokenizedWordLength']=df_tweets_tokenized['TokenizedWords'].str.len()
    df_tweets_tokenized_latest=df_tweets_tokenized[(~df_tweets_tokenized.TokenizedWords.isin(stop_words))]
    df_tweets_tokenized_latest=df_tweets_tokenized_latest.loc[(df_tweets_tokenized_latest['TokenizedWordLength']>2) ]
    del df_tweets_tokenized_latest['TokenizedWordLength']
    

#Total number of words including repititions
    print('\n','Afer Removing Stop Words and Words less than 2:Total number of words including repetitions')
    print(df_tweets_tokenized_latest['TokenizedWords'].count())

#Total number of distinct words
    print('\n','Afer Removing Stop Words and Words less than 2: Total number of distinct words')
    print(len(df_tweets_tokenized_latest['TokenizedWords'].unique()))


#Most 10 frequent words in the corpus after removing the stop words and the 2 letter words
    print('\n Afer Removing Stop Words and Words less than 2: Most 10 frequent words in the corpus')
    print(df_tweets_tokenized_latest[['TokenizedWords','TweetCount']].groupby(['TokenizedWords'],as_index=False).sum().nlargest(10,'TweetCount').to_string(index=False))

# Calling the function to print the historgram of words
    map_plot(df_tweets_tokenized_latest)

    
#-------------- This function is used for regex processing -----------------------
def Tweet_Process_1(df_tweet):

#Pre-processing the Tweets 1.2
#Replacing the name and URL references from the tweets. The name should be anoynmous due to privacy 
# and URL`s should be removed as it does not add value
    df_tweet['ModifiedTweet']= df_tweet['OriginalTweet'].copy().str.replace('@.*?\s|\shttps.*?\s|https.*$','').str.replace(' +',' ')    

#Removing the special characters &amp, &lt &gt and removing extra spaces
    df_tweet['ModifiedTweet']=df_tweet['ModifiedTweet'].str.replace("\&amp|amp|\&lt|\&gt|\x92s|'s",' ').str.replace(' +',' ')
#Removing some other special characters
    df_tweet['ModifiedTweet']=df_tweet['ModifiedTweet'].str.encode('ascii','ignore').str.decode('ascii','ignore').str.lower().str.replace('[\W]',' ').str.replace(' +',' ')
    
#Changing some lemma for key words
    df_tweet['ModifiedTweet']=df_tweet['ModifiedTweet'].str.replace('covid19 |convid19 |covid2019|covid19','covid ').str.replace(' +',' ')
    df_tweet['ModifiedTweet']=df_tweet['ModifiedTweet'].str.lstrip().str.rstrip()
    df_tweet['TokenizedWords']=df_tweet['ModifiedTweet'].str.split(" ")
        
    return df_tweet


''' -----------------The main program starts here ---------------'''
''' The following process has been followed to implement the Sentimental Analysis
    1. Read the Corona_NLP_train.csv file. Only the required columns are read
    2. Print the required values for analysis
    3. Call the Tweet_Process_1 function
        a. Applying the regex function and return the dataframe
    4. We are using multi-processing thread to process the sub-sequent parts
        a. Process1: Tweet_Process_2 : Use the dataframe to answer question 2 and 3
        b. Process2: binomial_nb: Use this function to answer Question 4
'''

#Start clocking the program
start_time=time.time()
if __name__ == '__main__':

#Reading the dataset 
    df_tweet= pd.read_csv('./data/Corona_NLP_train.csv',encoding='latin-1',usecols=['OriginalTweet','Sentiment','TweetAt'])

# After loading the data we are trying to check what the data looks like
# Adding a column 1 which makes it easier for doing calculation
# Calculate and print the analysis questions of the dataset like 
# The possible sentiments, the data maximum tweets received, second most populat tweet
    print('\n The possible Sentiments that the tweets can have are the below  (based on the dataset provided)')
    print(df_tweet['Sentiment'].unique())

    df_tweet['TweetCount']=1
    print('\nSecond Most Popular Sentiment  (based on the dataset provided)')
    print('',df_tweet[['Sentiment','TweetCount']].groupby(['Sentiment']).sum().nlargest(2,'TweetCount').iloc[1])

    print('\n Date which received the maximum Tweets (based on the dataset provided)')
    print('',df_tweet[['TweetAt','TweetCount','Sentiment']].loc[df_tweet['Sentiment']=='Extremely Positive'].groupby(['TweetAt'],as_index=False).sum().nlargest(1,'TweetCount'))

    df_tweet=df_tweet.drop(['TweetAt'],axis=1)
    df_tweet=Tweet_Process_1(df_tweet)

    p2 = Process(target=Tweet_Process_2(df_tweet[['OriginalTweet','TokenizedWords','TweetCount']]))
    p2.start()
    p2 = Process(target=binomial_nb(df_tweet[['ModifiedTweet','Sentiment']]))
    p2.start()

#Stop clocking the program    
    end_time=time.time() 
# Deleting the dataframe from memory as it is not required
    del df_tweet
#Print the the total time
    print('Total Time(in seconds):',end_time-start_time)

#------------------------------End of the Porgram ---------------